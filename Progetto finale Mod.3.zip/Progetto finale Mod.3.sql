CREATE DATABASE NEGOZIO DI VINILI

CREATE TABLE Cliente (
ID_cliente INT PRIMARY KEY,
Nome VARCHAR(50),
Cognome VARCHAR(50),
Email VARCHAR(100),
PwCliente VARCHAR(50),
Indirizzo VARCHAR(100),
Citt� VARCHAR(50),
Stato VARCHAR(50),
CAP VARCHAR(10),
);

CREATE TABLE Vinile (
ID_vinile INT PRIMARY KEY,
Titolo VARCHAR(100),
Artista VARCHAR(100),
Genere VARCHAR(50),
Prezzo DECIMAL(8, 2),
Anno_pubblicazione INT,
);

CREATE TABLE Ordine (
ID_ordine INT PRIMARY KEY,
ID_cliente INT,
Data_ordine DATE,
Totale DECIMAL(10, 2),
FOREIGN KEY (ID_cliente) REFERENCES Cliente (ID_cliente)
);

CREATE TABLE Dettaglio_ordine (
ID_ordine INT,
ID_vinile INT,
Quantit� INT,
FOREIGN KEY (ID_ordine) REFERENCES Ordine (ID_ordine),
FOREIGN KEY (ID_vinile) REFERENCES Vinile (ID_vinile),
PRIMARY KEY (ID_ordine, ID_vinile)
);

INSERT INTO Cliente (ID_cliente, Nome, Cognome, Email, PwCliente, Indirizzo, Citt�, Stato, CAP)
VALUES (1, 'Sabrina', 'Martini', 'sab.ma@email.com', 'p123', 'Via Roma 1', 'Milano', 'Italia', '20100');

INSERT INTO Cliente (ID_cliente, Nome, Cognome, Email, PwCliente, Indirizzo, Citt�, Stato, CAP)
VALUES (2, 'Stefania', 'Rossi', 'ste.ro@email.com', 'p456', 'Via Bari 15', 'Roma', 'Italia', '20100');

INSERT INTO Vinile (ID_vinile, Titolo, Artista, Genere, Prezzo, Anno_pubblicazione)
VALUES (1, 'Permission to Land', 'The Darkness', 'Rock', 14.99, 2003);

INSERT INTO Vinile (ID_vinile, Titolo, Artista, Genere, Prezzo, Anno_pubblicazione)
VALUES (2, 'Jagged Little Pill', 'Alanis Morisette', 'Pop', 34.99, 1995);

INSERT INTO Ordine (ID_ordine, ID_cliente, Data_ordine, Totale)
VALUES (1, 1, '2023-06-30', 14.99);

INSERT INTO Ordine (ID_ordine, ID_cliente, Data_ordine, Totale)
VALUES (2, 2, '2023-04-14', 34.99);

INSERT INTO Dettaglio_ordine (ID_ordine, ID_vinile, Quantit�)
VALUES (2, 1, 1);

INSERT INTO Dettaglio_ordine (ID_ordine, ID_vinile, Quantit�)
VALUES (1, 2, 4);

--Interrogazioni:


--Interrogazione 1:
--                 Vinili di genere "Rock" ordinati per titolo in ordine crescente.

SELECT * 
FROM Vinile
 WHERE Genere = 'Rock' 
ORDER BY Titolo ASC;

---Interrogazione 2:
--                 Numero totale di vinili venduti per ogni genere.

SELECT Genere, SUM(Quantit�) AS Totale_venduto
FROM Vinile
JOIN Dettaglio_ordine ON Vinile.ID_vinile = Dettaglio_ordine.ID_vinile
GROUP BY Genere;

---Interrogazione 3:
--                  Elenco dei clienti che hanno effettuato almeno un ordine dopo il 1� gennaio 2023.

SELECT DISTINCT Cliente.Nome, Cliente.Cognome
FROM Cliente
JOIN Ordine ON Cliente.ID_cliente = Ordine.ID_cliente
WHERE Ordine.Data_ordine > '2023-01-01';

---Interrogazione 4:
--                  Prezzo medio dei vinili per ogni artista.

SELECT Artista, AVG(Prezzo) AS Prezzo_medio
FROM Vinile
GROUP BY Artista;

---Interrogazione 5:
--                  Dettagli degli ordini per un cliente specifico con ID_cliente = 1.

SELECT Ordine.ID_ordine, Vinile.Titolo, Dettaglio_ordine.Quantit�
FROM Ordine
JOIN Dettaglio_ordine ON Ordine.ID_ordine = Dettaglio_ordine.ID_ordine
JOIN Vinile ON Dettaglio_ordine.ID_vinile = Vinile.ID_vinile
WHERE Ordine.ID_cliente = 1;

-----Interrogazione 6:
--                    Vinili di genere "Pop" ordinati per titolo in ordine decrescente.
SELECT * 
FROM Vinile
 WHERE Genere = 'Pop' 
ORDER BY Titolo DESC;

---Interrogazione 7:
--                  Elenco dei clienti che hanno effettuato almeno un ordine prima di del 14 Aprile 2023

SELECT DISTINCT Cliente.Nome, Cliente.Cognome
FROM Cliente
JOIN Ordine ON Cliente.ID_cliente = Ordine.ID_cliente
WHERE Ordine.Data_ordine <= '2023-04-14';

---Interrogazione 8:
--                  Prezzo per anno di pubblicazione album

SELECT Anno_pubblicazione, SUM(Prezzo) AS Prezzo.Album
FROM Vinile
Group By Anno_pubblicazione;

---Interrogazione 9:
--                  Totale Clienti

SELECT Count(Id_cliente) AS TotClienti
FROM Cliente;

---Interrogazione 10:
--                   Totale Acquistato nel 2023

SELECT SUM(Totale) AS TotAcq23
FROM Ordine
where Data_ordine > '2023-01-01'




